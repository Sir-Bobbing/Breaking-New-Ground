---
navigation:
  title: Creature Conjuration
  icon: malum:refined_brilliance
  parent: arcane.md
  position: 1
---
# Creature Conjuration
It has been found that there is a specific technique to conjure various mobs using spirit magics. You'll need to be acquainted with Malum before proceeding with this process...

---

#### Basics

Firstly it should be noted that all conjuration recipes show up in E.M.I. as the recipe for the mob's respective spawn egg. All conjuration recipes are done on the spirit altar.

Various inputs are needed to conjure mobs depending on it's properties. The main input will be a drop from the mob. It is important to use looting and extra spirit spoils to make this process a net profit for some mobs.

All conjurations require a form of experience. If it is a passive mob it will need <ItemLink id="malum:refined_brilliance"/><ItemImage id="malum:refined_brilliance"scale="0.6" />. If it is a hostile mob it will require a [Mnemonic Fragment](arcane_malum.md)<ItemImage id="malum:mnemonic_fragment"scale="0.6" />. Looking up the uses for these two items in **E.M.I.** can be useful for finding what all you can spawn.

The spirit inputs and catalyst inputs are all dependant on what spirits make up that particular mob. All catalysts are renewable, and some can be substituted with <ItemLink id="tfmg:copper_sulfate"/><ItemImage id="tfmg:copper_sulfate"scale="0.6" />.

---
#### Catalysts
Each spirit has a respective catalyst required to supplement it, they are as follows...

| Spirit | Catalyst | Substitutable |
| --- | --- | --- |
|<ItemImage id="malum:sacred_spirit"scale="0.6"/> - <ItemLink id="malum:sacred_spirit"/>|<ItemImage id="minecraft:quartz"scale="0.6"/> - <ItemLink id="minecraft:quartz"/>|✔|
|<ItemImage id="malum:wicked_spirit"scale="0.6"/> - <ItemLink id="malum:wicked_spirit"/>|<ItemImage id="minecraft:flint"scale="0.6"/> - <ItemLink id="minecraft:flint"/>|✔|
|<ItemImage id="malum:arcane_spirit"scale="0.6"/> - <ItemLink id="malum:arcane_spirit"/>|<ItemImage id="minecraft:amethyst_shard"scale="0.6"/> - <ItemLink id="minecraft:amethyst_shard"/>|✔|
|<ItemImage id="malum:eldritch_spirit"scale="0.6"/> - <ItemLink id="malum:eldritch_spirit"/>|<ItemImage id="architects_palette:unobtanium"scale="0.6"/> - <ItemLink id="architects_palette:unobtanium"/>|❌|
|<ItemImage id="malum:aerial_spirit"scale="0.6"/> - <ItemLink id="malum:aerial_spirit"/>|<ItemImage id="minecraft:pointed_dripstone"scale="0.6"/> - <ItemLink id="minecraft:pointed_dripstone"/>|✔|
|<ItemImage id="malum:aqueous_spirit"scale="0.6"/> - <ItemLink id="malum:aqueous_spirit"/>|<ItemImage id="minecraft:clay_ball"scale="0.6"/> - <ItemLink id="minecraft:clay_ball"/>|❌|
|<ItemImage id="malum:earthen_spirit"scale="0.6"/> - <ItemLink id="malum:earthen_spirit"/>|<ItemImage id="spelunkery:stone_pebble"scale="0.6"/> - <ItemLink id="spelunkery:stone_pebble"/>|❌|
|<ItemImage id="malum:infernal_spirit"scale="0.6"/> - <ItemLink id="malum:infernal_spirit"/>|<ItemImage id="minecraft:glowstone_dust"scale="0.6"/> - <ItemLink id="minecraft:glowstone_dust"/>|❌|

---
#### Special Conjuration
There are certain conjurations that do not follow known norms. There is currently only one known special conjuration and that is the mimic. Refer to E.M.I. for instructions but be weary of the inbalanced arcane forces involved.