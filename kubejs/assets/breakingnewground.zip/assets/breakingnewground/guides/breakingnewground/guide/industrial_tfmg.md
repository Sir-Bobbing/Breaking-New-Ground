---
navigation:
  title: The Factory Must Grow
  icon: tfmg:radial_engine
  parent: industrial.md
  position: 8
---
# The Factory Must Grow

Get ready to get your hands dirty. TFMG (The Factory Must Grow) has more complicated machines and interconnected recipes than base Create has. It's recommend having a good grasp on [Create](industrial_create.md) before getting too deep into TFMG. *E.M.I. is your friend here...*

---

### What is possible?
TFMG allows the crafting of certain high tiers materials and some useful machines for any contraptions you may have.
- Powerful fuels for thrusters
- Strong and compact engines for contraptions
- <ItemLink id="tfmg:firebox"/>
- Access to [electricity](industrial_powergrid.md)
- <ItemLink id="toms_storage:adv_wireless_terminal"/>
- Ore refinement up to 2x
- High tier [guns](industrial_guns.md)
- Exo-Suit

---

### Coking

One of your first goals in TFMG will be getting steel, but to do that you will need a rich source of carbon. <ItemLink id='tfmg:coal_coke'/> can be obtained by coking <ItemLink id='minecraft:coal'/> in a <ItemLink id='tfmg:coke_oven'/>. The ponder for the <ItemLink id='tfmg:coke_oven'/> can explain it's mechanics fairly well. Only thing it doesn't explain is that the coke oven can be built in multiple sizes, although it is slower the smaller it is.

<GameScene zoom="2" interactive={true}>  
<ImportStructure src="coke_oven_sizes.nbt" />
</GameScene>

<ItemLink id='tfmg:coal_coke'/> is also used in a handful of Power Grid recipes.

---

### Exhausting Work

You may have noticed that the coke ovens output carbon dioxide as a bi-product of their work. Many machines and engines in TFMG do this. Machines will stop working if their exhaust is not removed. Carbon dioxide can be pumped into the world and will be voided. If you want some more decorative flare there are a few options available.

<GameScene zoom="2" interactive={true}>  
<ImportStructure src="exhaust_example.nbt" />
</GameScene>

---

### Creosote

Creosote is a by-product of coking coal or logs. Creosote can be used to make <ItemLink id='tfmg:hardened_planks'/> which is a primary ingredient in <ItemLink id='powergrid:conductive_casing'/>, the casing of the electrical age. Creosote also has some use in starting your hot air loop for steel production.

---

### Blast Stove

To make steel you need hot air. The <ItemLink id='tfmg:blast_stove'/> is used to make hot air. It's ponder explains it's use well, but not it's recipe. Blast stoves take fuel to run and that can either be creosote or furnace gas. Furnace gas is a by-product of the blast furnace so can be recycled to keep making hot air without burning any creosote. Creosote only acts a starter for the hot air loop.

---

### Blast Furnace

Finally all the parts come together to make <ItemLink id='tfmg:steel_ingot'/> in a blast furnace! Best place to start is the ponder for the <ItemLink id='tfmg:blast_furnace_output'/>. Put <ItemLink id='minecraft:iron_ingot'/>, <ItemLink id='tfmg:limesand'/>, and <ItemLink id='tfmg:coal_coke_dust'/> into the blast furnace to make molten steel and slag. From there you can pump your molten steel into a <ItemLink id='tfmg:casting_basin'/> to make <ItemLink id='tfmg:steel_ingot'/>*s*. It should be noted that items are dropped as physical entities internally in the blast furnace so it's best to drop items in as complete batches together. If automating this use either a <ItemLink id='create:brass_tunnel'/> or a <ItemLink id='create:repackager'/> on a timer.

- The blast furnace structure (not including hatch) must be at least 3 blocks tall to function. It operates faster if taller.
- The hot air input hatch can not be on the same layer as the furnace output, but can replace any fireproof bricks elsewhere in the structure.
- Capable of doing 2x ore refinement recipes.

---

### Steel Mechanisms

<ItemLink id='tfmg:steel_mechanism'/> are a crucial crafting component from this point forward for TFMG. It is best to have them automated. Can also be dropped from cog enemies.

---

### Black Gold

Some of the next steps of TFMG require oil. Firstly you'll have to locate a <ItemLink id='tfmg:oil_deposit'/>, which is best done with a <ItemLink id='tfmg:surface_scanner'/> as they are located at the very bottom of the world. The scanners do behave... weirdly... on contraptions but still should be useful for catching deposits. Also shows up while [prospecting](world_prospecting.md). Sometimes an oil well will spill out all the way to the surface in desert biomes making for easy spotting.

<GameScene>
	<Block id="minecraft:granite" y="1" /> 	<Block id='tfmg:surface_scanner'  y= "1" />
	<Block id="create:veridium" /> 	<Block id='tfmg:machine_input' />
</GameScene>

Otherwise, the ponder for the <ItemLink id='tfmg:pumpjack_base'/> explains the rest of the oil extraction process fairly well. Just pump out the oil from the base.

---

### Distillation

The distillery is capable of splitting up fluids into seperate components, which is particularly useful for oil, heavy oil, and slag. Refer to the ponder for the <ItemLink id='tfmg:steel_distillation_controller'/> for further instruction on usage. Do note that the <ItemLink id='tfmg:steel_distillation_output'/> can be set to void excess fluids that you don't want, otherwise the machine stops if any output is full.

---

### The Vat

The <ItemLink id='tfmg:cast_iron_chemical_vat'/> and it's variations are a multiblock of several uses. Again, it's ponder explains it's function well but there are some things to elaborate on. E.M.I. is your friend with this block as it's capable of a wide assortment of recipes.

- As mentioned there are multiple tiers of chemical vat:
<ItemGrid>
<ItemIcon id='tfmg:cast_iron_chemical_vat'/> 
<ItemIcon id='tfmg:steel_chemical_vat'/> 
<ItemIcon id='tfmg:fireproof_chemical_vat'/>
</ItemGrid>

The cast iron is the lowest tier, steel is mid, and fireproof is highest. A higher tier vat is capable of doing all of the lower tier recipes. In E.M.I. it can't be discerened which recipes require a cast iron vat or a steel vat. If the recipe requires electrodes will need either a steel or a fireproof vat. The difference between a steel and fireproof vat is very obvious in E.M.I.

- Electrodes require Power Grid electricity to be ran

---

### Circuit Boards

Really the end goal of TFMG is to manufacture <ItemLink id='tfmg:circuit_board'/>*s*. To get there you'll need to automate a variety of things both from TFMG and Power Grid. E.M.I. can show you the require ingredients to craft it.

---

### Engines

TFMG provides a handful of fuel powered engines. Take notice, they are LOUD. All produce carbon dioxide that must be pumped out. There are two sets of distinct engines, the standard ones and the large ones.
#### Standard Engines
- Can be chained together to up to 5 blocks long
- Require a redstone signal to run
- Require additional components to be fully assembled once placed. Components will be shown with goggles
- Components can be removed with a <ItemLink id='tfmg:screwdriver'/>. May not drop all components if broken normally
- Require pistons or turbines which determine what fuels the engine can use
- If you press <KeyBind id="key.use" /> with an <ItemLink id='create:empty_schematic'/> on a un-assembled regular engine, it will change piston orientation
- Can apply a <ItemLink id='tfmg:turbo'/> or <ItemLink id='tfmg:golden_turbo'/> to increase power at an efficiency cost.
<ItemGrid>
<ItemIcon id='tfmg:regular_engine'/>
<ItemIcon id='tfmg:radial_engine'/> 
<ItemIcon id='tfmg:turbine_engine'/> 
</ItemGrid>
#### Large Engines
- Require air to be pumped in as well as fuel
- Run automatically without redstone input
- Do not vary in performance based on fuel
- Function similarly to <ItemLink id='create:steam_engine'/>*s*, requiring a shaft to be added to turn
<ItemGrid>
<ItemIcon id='tfmg:large_engine'/>
<ItemIcon id='tfmg:simple_large_engine'/> 
</ItemGrid>

| Engine                                    | Creosote | Diesel | Kerosene | Naptha | Gasoline | LPG |
| ----------------------------------------- | -------- | ------ | -------- | ------ | -------- | --- |
| <ItemLink id='tfmg:regular_engine'/>      | ✔        | ✔      | ✔        | ✔      | ✔        | ✔   |
| <ItemLink id='tfmg:radial_engine'/>       | ✔        | ✔      | ✔        | ✔      | ✔        | ✔   |
| <ItemLink id='tfmg:turbine_engine'/>      | ❌        | ❌      | ✔        | ❌      | ❌        | ❌   |
| <ItemLink id='tfmg:large_engine'/>        | ❌        | ✔      | ✔        | ✔      | ❌        | ❌   |
| <ItemLink id='tfmg:simple_large_engine'/> | ❌        | ✔      | ✔        | ✔      | ❌        | ❌   |


