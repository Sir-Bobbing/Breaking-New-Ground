---
navigation:
  title: Power Grid
  icon: powergrid:generator_large_induction_rotor
  parent: industrial.md
  position: 9
---
# Power Grid

Power Grid provides a simplified simulation of DC electricity, allowing you to power your base with electrons. It should be noted that realistic electrical concepts will be involved. *Work by wire...*

---

### What is possible?
Power Grid enables the use of certain high tier TFMG machines. Additionally has some cool gizmos for your inner electrical engineer.
- Electrocute things
- Custom circuit boards
- Faster bulk processing
- Accelerate crop growth
- Electricity powered thrusters
- Electricity powered blaze burner
- Electricity powered tools
- Ore refinement up to 4x
- Electricity powered [guns](industrial_guns.md)
- Exo-Suit modules (Including a jetpack!)
- Electrocute things

---

### Now watt?

You can think Power Grid's electricity system as a more complex version of Create's stress unit system. Luckily Power Grid has decent ponders on how to use it's mechanics. To begin with you'll need to generate power so the <ItemLink id='powergrid:generator_induction_rotor'/> is a good place to start. What Power Grid doesn't explain though is the basics of electrical engineering...

---

### So you think you can be an engineer?

##### This will be a simplified explaination of electricity and should suffice for Power Grid.



