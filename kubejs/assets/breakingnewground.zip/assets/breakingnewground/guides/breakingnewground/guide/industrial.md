---
navigation:
  title: The Industrial
  icon: create:goggles
  position: 4
categories:
  - The Industrial  
---
# The Industrial
WIP

---
<SubPages icons={true}></SubPages>