---
navigation:
  title: The Industrial
  icon: create:goggles
  position: 4
categories:
  - The Industrial  
---
# The Industrial
All things mechanical are here. From a simple workshop, to entire factories with elaborate power networks. With the right infrastructure you can bend the world to your desires.

---
<SubPages icons={true}></SubPages>