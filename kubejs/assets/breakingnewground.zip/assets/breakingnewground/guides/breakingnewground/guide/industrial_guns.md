---
navigation:
  title: 'Firearms'
  icon: scguns:flintlock_pistol
  parent: industrial.md
  position: 7
---
# Firearms
# ⚠\[NOTICE]⚠
Scorched Guns does require progression in [Create](industrial_create.md). Early tiers won't need Create at all. You'll be fine with a <ItemLink id="create:mechanical_mixer"/> and a <ItemLink id="create:blaze_burner"/> through mid-tier. It is not until you get to into the higher tiers where you'll need things from [TFMG](industrial_tfmg.md) or [Power Grid](industrial_powergrid.md).

---
Guns have a long history. From simple flintlocks, to complicated automated killing machines.

Each firearm is specialized and often made by different groups for their own different purposes.

---
## Getting Started
in order to craft any firearms you'll need to craft a **Gun Bench** <ItemImage id="scguns:gun_bench" scale="0.5"/>
<Recipe id="scguns:gun_bench" /> 
The trickier part is getting the parts needed. to make your guns. such as the **Blueprints**

---
## Gun Tiers
The guns come in tiers, all requiring a special blueprint to be able to craft them. many use different types of ammunition or can occasionally have special traits, such as being able to shoot under water, or reap souls.
#### Antique
<ItemGrid>  
<ItemIcon id="scguns:antique_blueprint" /> 
<ItemIcon id="scguns:flintlock_pistol" /> 
<ItemIcon id="scguns:handcannon" /> 
<ItemIcon id="scguns:musket" /> 
<ItemIcon id="scguns:blunderbuss" /> 
<ItemIcon id="scguns:fencer_carabine" /> 
<ItemIcon id="scguns:fencer_thumper" /> 
<ItemIcon id="scguns:doublet" /> 
<ItemIcon id="scguns:repeating_musket" /> 
<ItemIcon id="scguns:longarm" /> 
<ItemIcon id="scguns:laser_musket" /> 
<ItemIcon id="scguns:teslock_rifle" /> 
<ItemIcon id="scguns:plasmabuss" /> 
</ItemGrid>
---
#### Frontier
<ItemGrid>  
<ItemIcon id="scguns:frontier_blueprint" /> 
<ItemIcon id="scguns:pax" /> 
<ItemIcon id="scguns:winnie" /> 
<ItemIcon id="scguns:winnie_millend" /> 
<ItemIcon id="scguns:callwell" /> 
<ItemIcon id="scguns:callwell_conversion" /> 
<ItemIcon id="scguns:callwell_terminal" /> 
<ItemIcon id="scguns:saketini" /> 
<ItemIcon id="scguns:red_raydar" /> 
<ItemIcon id="scguns:big_bore" /> 
<ItemIcon id="scguns:saketini_ironport" /> 
</ItemGrid>
---
#### Copper
<ItemGrid>  
<ItemIcon id="scguns:copper_blueprint" /> 
<ItemIcon id="scguns:scrapper" /> 
<ItemIcon id="scguns:rusty_gnat" /> 
<ItemIcon id="scguns:umax_pistol" /> 
<ItemIcon id="scguns:makeshift_rifle" /> 
<ItemIcon id="scguns:boomstick" /> 
<ItemIcon id="scguns:bruiser" /> 
<ItemIcon id="scguns:llr_director" /> 
<ItemIcon id="scguns:birdfeeder" /> 
<ItemIcon id="scguns:whistler" /> 
<ItemIcon id="scguns:blooper" /> 
<ItemIcon id="scguns:arc_worker" /> 
</ItemGrid>
---
#### Iron, Wrecker & Ocean
<ItemGrid>  
<ItemIcon id="scguns:iron_blueprint" /> 
<ItemIcon id="scguns:defender_pistol" /> 
<ItemIcon id="scguns:trenchur" /> 
<ItemIcon id="scguns:greaser_smg" /> 
<ItemIcon id="scguns:m3_carabine" /> 
<ItemIcon id="scguns:m3_marksman" /> 
<ItemIcon id="scguns:combat_shotgun" /> 
<ItemIcon id="scguns:venturi" /> 
<ItemIcon id="scguns:iron_javelin" /> 
<ItemIcon id="scguns:iron_spear" /> 
<ItemIcon id="scguns:auvtomag" /> 
<ItemIcon id="scguns:pulsar" /> 
<ItemIcon id="scguns:gyrojet_pistol" /> 
<ItemIcon id="scguns:brawler" /> 
<ItemIcon id="scguns:crusader" /> 
<ItemIcon id="scguns:mk43_rifle" /> 
<ItemIcon id="scguns:triquetra" /> 
<ItemIcon id="scguns:rocket_rifle" /> 
<ItemIcon id="scguns:ultra_knight_hawk" /> 
</ItemGrid>
<ItemGrid>  
<ItemIcon id="scguns:wrecker_blueprint" /> 
<ItemIcon id="scguns:mokova" /> 
<ItemIcon id="scguns:mak_mkii" /> 
<ItemIcon id="scguns:railworker" /> 
<ItemIcon id="scguns:whizzbanger" /> 
<ItemIcon id="scguns:turnpike" /> 
<ItemIcon id="scguns:killer_23" /> 
<ItemIcon id="scguns:homemaker" /> 
<ItemIcon id="scguns:kalaskah" /> 
<ItemIcon id="scguns:basker" /> 
<ItemIcon id="scguns:tl_runner" /> 
<ItemIcon id="scguns:stigg" /> 
<ItemIcon id="scguns:stiletto" /> 
</ItemGrid>
<ItemGrid>  
<ItemIcon id="scguns:ocean_blueprint" /> 
<ItemIcon id="scguns:floundergat" /> 
<ItemIcon id="scguns:marlin" /> 
<ItemIcon id="scguns:bomb_lance" /> 
<ItemIcon id="scguns:hullbreaker" /> 
<ItemIcon id="scguns:sequoia" /> 
<ItemIcon id="scguns:spirulida" /> 
<ItemIcon id="scguns:hyperbaria" /> 
</ItemGrid>
---
#### Treated Brass & Piglin
<ItemGrid>  
<ItemIcon id="scguns:treated_brass_blueprint" /> 
<ItemIcon id="scguns:m22_waltz" /> 
<ItemIcon id="scguns:waltz_conversion" /> 
<ItemIcon id="scguns:osgood_50" /> 
<ItemIcon id="scguns:grandle_og" /> 
<ItemIcon id="scguns:grandle" /> 
<ItemIcon id="scguns:cogloader" /> 
<ItemIcon id="scguns:gale" /> 
<ItemIcon id="scguns:jr_wristbreaker" /> 
<ItemIcon id="scguns:jackhammer" /> 
<ItemIcon id="scguns:hammer_gl" /> 
<ItemIcon id="scguns:howler" /> 
<ItemIcon id="scguns:howler_conversion" /> 
<ItemIcon id="scguns:gauss_rifle" /> 
<ItemIcon id="scguns:libertas" /> 
<ItemIcon id="scguns:niami" /> 
<ItemIcon id="scguns:spitfire" /> 
<ItemIcon id="scguns:gattaler" /> 
<ItemIcon id="scguns:thunderhead" /> 
<ItemIcon id="scguns:scratches" /> 
<ItemIcon id="scguns:cr4k_mining_laser" /> 
<ItemIcon id="scguns:dozier_rl" /> 
</ItemGrid>
<ItemGrid>  
<ItemIcon id="scguns:piglin_blueprint" /> 
<ItemIcon id="scguns:empty_blasphemy" /> 
<ItemIcon id="scguns:pyroclastic_flow" /> 
<ItemIcon id="scguns:freyr" /> 
<ItemIcon id="scguns:mangalitsa" /> 
<ItemIcon id="scguns:vulcanic_repeater" /> 
<ItemIcon id="scguns:trotters" /> 
</ItemGrid>
---
#### Diamond Steel & Deep Dark
<ItemGrid>  
<ItemIcon id="scguns:diamond_steel_blueprint" /> 
<ItemIcon id="scguns:krauser" /> 
<ItemIcon id="scguns:soul_drummer" /> 
<ItemIcon id="scguns:uppercut" /> 
<ItemIcon id="scguns:micina" /> 
<ItemIcon id="scguns:valora" /> 
<ItemIcon id="scguns:prush_gun" /> 
<ItemIcon id="scguns:drill" /> 
<ItemIcon id="scguns:drill_conversion" /> 
<ItemIcon id="scguns:lockewood" /> 
<ItemIcon id="scguns:rg_jigsaw" /> 
<ItemIcon id="scguns:nailer" /> 
<ItemIcon id="scguns:inertial" /> 
<ItemIcon id="scguns:minksy" /> 
<ItemIcon id="scguns:mas_peddler" /> 
<ItemIcon id="scguns:mas_55" /> 
<ItemIcon id="scguns:inquisitor" /> 
<ItemIcon id="scguns:plasgun" /> 
<ItemIcon id="scguns:cyclone" /> 
<ItemIcon id="scguns:zilk_45" /> 
<ItemIcon id="scguns:truant" /> 
<ItemIcon id="scguns:shard_culler" /> 
</ItemGrid>
<ItemGrid>  
<ItemIcon id="scguns:deep_dark_blueprint" />
<ItemIcon id="scguns:whispers" /> 
<ItemIcon id="scguns:echoes_2" /> 
<ItemIcon id="scguns:sculk_resonator" /> 
<ItemIcon id="scguns:forlorn_hope" />  
</ItemGrid>
---
#### End
<ItemGrid>  
<ItemIcon id="scguns:end_blueprint" /> 
<ItemIcon id="scguns:dark_matter" /> 
<ItemIcon id="scguns:lone_wonder" /> 
<ItemIcon id="scguns:raygun" /> 
</ItemGrid>
---
## Ammo Storage
To help prevent your inventory from filling up, there exists various types of ammo containers. each holding their respective type of ammunition.

each one can hold up to four stacks of bullets, a total of 1024 bullets.

<ItemGrid>  
<ItemIcon id="scguns:pistol_ammo_box" /> 
<ItemIcon id="scguns:rifle_ammo_box" /> 
<ItemIcon id="scguns:shotgun_ammo_box" /> 
<ItemIcon id="scguns:magnum_ammo_box" /> 
<ItemIcon id="scguns:energy_ammo_box" /> 
<ItemIcon id="scguns:rocket_ammo_box" /> 
<ItemIcon id="scguns:special_ammo_box" /> 
<ItemIcon id="scguns:empty_casing_pouch" /> 
</ItemGrid>

The **Empty Casing Pouch** <ItemImage id="scguns:empty_casing_pouch" scale="0.5"/> will automatically catch any spent casings, instead of letting them drop on the floor.

---
*note: many scorched guns items and resources have an info tab when inspecting their uses, when using E.M.I.*

*note: you can figure out where to find anthralite in the [prospecting](industrial_prospecting.md) section*
