---
navigation:
  title: Malum
  icon: malum:encyclopedia_arcana
  parent: arcane.md
  position: 1
---
# Malum
The Reclaimer's Manual presently is missing most information on the arts of 'Spirit Magic' 

---
To get Started with Malum. You must find and obtain Soulstone <ItemImage id="malum:raw_soulstone" scale="0.5"/> and refine it. With your product you will be able to craft it with a book. Giving you with the Encyclopedia Arcana <ItemImage id="malum:encyclopedia_arcana" scale="0.5"/> .

<Row>
 <Recipe id="malum:soulstone_from_raw_smelting" />
 <Recipe id="malum:encyclopedia_arcana" />
</Row>
---

## Ancient Knowledge
It has been rumored that certain [arcane structures](industrial_prospecting.md) can reveal hidden truths to those whom interact with it. This information will not be fully absorbed into your E.M.I. until you either restart your instance or press F3 + T.