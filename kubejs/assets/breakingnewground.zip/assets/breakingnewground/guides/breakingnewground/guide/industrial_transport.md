---
navigation: 
  title: 'Getting Around'
  icon: 'aeronautics:aviators_goggles'
  parent: industrial.md
  position: 4
---
# Getting Around
Most information regarding industry and machines should already be implanted inside your mind with the help of the
PsychON Deposition and Encoding Revision (PONDER) system.

---
## Building Blocks 
##### Physics Assembler
One of the simplest things you need to know. is in order to make any sort of contraption or car. you will need a **Physics Assembler** <ItemImage id='simulated:physics_assembler' scale="0.5"/>.

Without this you're not going to be doing much admitteldly. the PONDER system should hopefully carry you from here.
 <Recipe id="simulated:physics_assembler" />
 ---
## Other
##### Asphalt
A block sourced from **bitumen**<ItemImage id='tfmg:bitumen' scale="0.5"/>. **Asphalt**<ItemImage id='tfmg:asphalt' scale="0.5"/> has a unique trait of allowing you to move faster when walking or running on it.

In order to get the block, you'll need to place or pump liquid asphalt into the world, and let it dry.
<ItemGrid>  
<ItemIcon id="tfmg:liquid_asphalt_bucket" /> 
<ItemIcon id="tfmg:asphalt" /> 
</ItemGrid>