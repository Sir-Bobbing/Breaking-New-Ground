---
navigation:
  title: Information Manual
  icon: create:desk_bell
---
# Information Manual

# ⚠\[WARNING]⚠
If you try to play this like normal Minecraft, you WILL have a bad time.

---

Greetings! If you are able to read this. That means you're cognizant enough to be able to read this guide!
Beings like you have been missing from the Overworld for a long time!

And things have changed in the Eons, long enough that the last past has been forgotten. Even you may not be able to know where you're from or who you are fully

However the past is the past and the present is **Now**. And what that means is you must explore, build and construct. For the Overworld is a garden anew for us to tend to its grounds.

As always, if you're, the Manual has most of the information you will need. If that's not enough.  Remember to use your Encyclopedic Master Interface (**E.M.I**)

---
## Table of Contents
<CategoryIndex category="The World" />
<CategoryIndex category="The Industrial" />
<CategoryIndex category="The Arcane" />
<CategoryIndex category="The Minutiae" />
<CategoryIndex category="Other Resources" />