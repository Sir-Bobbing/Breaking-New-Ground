---
navigation:
  title: Miscellaneous Utilities
  icon: 'minecraft:crafting_table'
  position: 5
  parent: minutiae.md
---
# Miscellaneous Utilities
The following is a simple list of useful bits of knowledge that might be missing from your mind.

---

## Workstations
##### Anvil
- No longer has exponential XP costs
- Renaming costs only One Level
##### Trading Post
- Allows you to trade with all Villagers within a 24x16x24 block radius
<Recipe id="tradingpost:trading_post" />

---
## Equipment
##### Chalk
- Able to make arrows and other symbols when used. (<KeyBind id="key.sneak"/> to open symbol window).
- Comes in all 16 colors.
- Chalk box holds up to 8 chalk (Use <KeyBind id="key.sneak"/> + <KeyBind id="key.use"/> to cycle).
- If glowstone dust or glow ink is in the chalk box, chalk *glows* (limited uses before needing to be refilled).
- Can be used on **Blackboards** <ItemImage id="supplementaries:blackboard" scale="0.5"/>.
<Row>
<RecipesFor id="chalk:white_chalk" />
<RecipesFor id="chalk:chalk_box" />
</Row>
##### Writing
- Writing in a book now allows you to format the text style and color by highlighting it.
- Dying books changes its appearance inside the User Interface.
- Dual page editing.
##### Bundles
- Exists
- Can use the scroll wheel to select the item you want to pull out
<Row>
<RecipesFor id="minecraft:bundle" />
</Row>
##### Wrench
- Allows you to rotate the orientation of blocks.
- Plays a funny noise when hitting a mob.
<Recipe id="supplementaries:wrench" />
##### Atlas 
- Mentioned in [The Overworld](world_the_overworld.md)
- Renaming a book to **"Antique Atlas"** in an anvil will give you an item version of the atlas.
##### Altimeter
- Displays current altitude
<Recipe id="supplementaries:altimeter" />
## Miscellaneous
##### Tripwire Hooks
- Holding a tool and using <KeyBind id="key.use" /> + <KeyBind id="key.sneak" /> on a tripwire hook will hang the tool on the hook
##### Mirrors
- Shows a real time reflection of the world.
<Recipe id="vista:mirror" />
*Tip: Crystalline drops from Elder Guardians*

*Tip: many mirrors lag... very badly.*

##### Storage Labels 
- Labels functions similar to Item Frames but can adapt to all surfaces.
- By using <KeyBind id="key.use" /> + <KeyBind id="key.sneak" />, you can change the icon of the label to the held item.
- Doesn't block interaction with the block its on (unlike Signs or Item Frames)
- Accepts Glow Ink Sacks to make then glow in the dark.
- Can be colored with any dye.
- Using a Feather on them will display the item name.
- Can be removed by simply using <KeyBind id="key.attack" />
<Recipe id="labels:label" />